package Spc.View;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Spc.Controller.*;

public class Interface extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textcodspc;
    private JTextField textnome;
    private JTextField textidade;
    private JTextField textdata;
    private Controllerinterface cjs = new Controllerinterface();
    private JLabel lblStatus;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Interface frame = new Interface();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Interface() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 276, 288);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblCadastroDeSpc = new JLabel("CADASTRO DE SPC\u00D5ES");
        lblCadastroDeSpc.setFont(new Font("Tahoma", Font.BOLD, 14));
        lblCadastroDeSpc.setBounds(40, 11, 198, 24);
        contentPane.add(lblCadastroDeSpc);

        JLabel lblcodspc = new JLabel("codspc:");
        lblcodspc.setBounds(10, 49, 46, 14);
        contentPane.add(lblcodspc);

        JLabel lblnome = new JLabel("nome:");
        lblnome.setBounds(10, 74, 46, 14);
        contentPane.add(lblnome);

        JLabel lblidade = new JLabel("idade:");
        lblidade.setBounds(10, 99, 46, 14);
        contentPane.add(lblidade);

        JLabel lbldata = new JLabel("data:");
        lbldata.setBounds(10, 129, 46, 14);
        contentPane.add(lbldata);

        textcodspc = new JTextField();
        textcodspc.setBounds(50, 46, 46, 20);
        contentPane.add(textcodspc);
        textcodspc.setColumns(10);

        textnome = new JTextField();
        textnome.setBounds(50, 71, 86, 20);
        contentPane.add(textnome);
        textnome.setColumns(10);

        textidade = new JTextField();
        textidade.setBounds(50, 99, 86, 20);
        contentPane.add(textidade);
        textidade.setColumns(10);

        textdata = new JTextField();
        textdata.setBounds(50, 126, 200, 20);
        contentPane.add(textdata);
        textdata.setColumns(10);

        lblStatus = new JLabel("Status: Desconectado");
        lblStatus.setFont(new Font("Tahoma", Font.BOLD, 11));
        lblStatus.setBounds(10, 188, 128, 14);
        contentPane.add(lblStatus);

        testarConexao(); // Verificar a conexão antes do botão ser pressionado
        
        JButton btnCadastrar = new JButton("CADASTRAR");
        btnCadastrar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int codspc = Integer.parseInt(textcodspc.getText());
                String nome = textnome.getText();
                int idade = Integer.parseInt(textidade.getText());
                String data = textdata.getText();

                    cjs.incluirSessao(codspc, nome, idade, data);
                    JOptionPane.showMessageDialog(null, "Sessão cadastrada com sucesso!");
                    textcodspc.setText("");
                    textnome.setText("");
                    textidade.setText("");
                    textdata.setText("");
            }
        });
        btnCadastrar.setBounds(47, 154, 119, 23);
        contentPane.add(btnCadastrar);
    }
    
    private boolean testarConexao() {
        String url = "jdbc:mysql://localhost:3306/4mod?useSSL=false";
        String username = "root";
        String password = "";

        try {
            Connection conexao = DriverManager.getConnection(url, username, password);
            conexao.close();
            lblStatus.setText("Status: Conectado");
            lblStatus.setForeground(Color.GREEN);
            return true;
        } catch (SQLException e) {
            lblStatus.setText("Status: Desconectado");
            lblStatus.setForeground(Color.RED);
            return false;
        }
    }
}
