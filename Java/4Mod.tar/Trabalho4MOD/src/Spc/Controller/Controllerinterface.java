package Spc.Controller;

import Spc.Domain.*;

public class Controllerinterface {
	private Spc se = new Spc(0, null, 0, null);
	private DaoSpc daoSe = new DaoSpc();
	
	public void incluirSessao(int codspc, String nome, int idade, String data) {
		se.setCodSPC(codspc);
		se.setNome(nome);
		se.setIdade(idade);
		se.setData(data);
		
		daoSe.inserir(codspc, se.formatarData(), nome, idade);
	}
}
	