package Spc.Controller;

import Spc.View.*;

public class DaoController {
	public static void main(String[] args) {
		Interface js = new Interface();

		js.setVisible(true);
	}
}
