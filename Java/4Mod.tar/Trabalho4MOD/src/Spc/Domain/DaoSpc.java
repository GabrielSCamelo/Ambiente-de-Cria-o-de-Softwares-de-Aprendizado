package Spc.Domain;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DaoSpc {
	static final String url = "jdbc:mysql://localhost:3306/4mod?useSSL=false";
    static final String username = "root";
    static final String password = "";

    public void inserir(int codspc, String nome, String data, int idade) {
    	String sql = "INSERT INTO spc (codspc, nome, idade, data) VALUES ('" + codspc + "', '" + nome + "', '" + idade + "', " + data + ")";

        try {
            Connection conexao = DriverManager.getConnection(url, username, password);
            PreparedStatement inclusao = conexao.prepareStatement(sql);
            inclusao.execute();
        } catch (SQLException e) {
            System.out.println("Não foi possível acessar o banco de dados");
        }
    }
}
