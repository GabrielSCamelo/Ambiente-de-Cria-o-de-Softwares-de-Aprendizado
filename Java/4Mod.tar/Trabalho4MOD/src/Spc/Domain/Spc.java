package Spc.Domain;

public class Spc {
	
	private int CodSPC;
	private int idade;
	private String nome;
	private String data;
	
	public Spc(int codspc, String nome, int idade, String data) {
		super();
		CodSPC = codspc;
		this.nome = nome;
		this.idade = idade;
		this.data = data;
	}
	
	public int getCodSPC() {
		return CodSPC;
	}
	public void setCodSPC(int codSPC) {
		CodSPC = codSPC;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	public String formatarData() {
		return data.substring(6, 10) + "-" +
			   data.substring(3, 5) + "-" +
			   data.substring(0, 2);
	}

}
